DELETE FROM `quest` WHERE `name` = 'Frostheart';
INSERT INTO `quest` (`id`, `name`, `min_Delta`, `max_Solves`, `message`) VALUES ('999500', 'Frostheart', '0', '10', 'Frost Dragon');