DELETE FROM `landblock_instance` WHERE `landblock` = 61655;


INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F0D7000, 5000766, 0xF0D70040, 191.84721, 174.23529, -0.045000028, -0.9341002, 0, 0, -0.35701084, False, '2020-05-07 19:23:48'); /* Shreth gen */
/* @teleloc 0xF0D70040 [191.847214 174.235291 -0.045000] -0.934100 0.000000 0.000000 -0.357011 */