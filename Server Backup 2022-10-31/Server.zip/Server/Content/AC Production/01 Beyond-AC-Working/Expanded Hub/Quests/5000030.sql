
DELETE FROM `quest` WHERE (`id` = '5000030');
INSERT INTO `quest` (`id`, `name`, `min_Delta`, `max_Solves`, `message`, `last_Modified`) VALUES ('5000030', 'WardenShen', '0', '1', 'WardenShen', '2019-09-05 19:03:38');