
DELETE FROM `quest` WHERE (`id` = '5000032');
INSERT INTO `quest` (`id`, `name`, `min_Delta`, `max_Solves`, `message`, `last_Modified`) VALUES ('5000032', 'WardenVSQ', '0', '1', 'WardenVSQ', '2019-09-05 19:03:38');