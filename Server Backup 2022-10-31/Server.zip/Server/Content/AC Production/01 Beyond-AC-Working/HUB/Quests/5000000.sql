DELETE FROM `quest` WHERE (`id` = '5000000');
INSERT INTO `quest` (`id`, `name`, `min_Delta`, `max_Solves`, `message`) VALUES ('5000000', 'YS', '0', '1', 'Yanshi Shadows');