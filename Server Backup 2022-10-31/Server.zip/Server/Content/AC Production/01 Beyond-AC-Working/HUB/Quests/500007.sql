
DELETE FROM `quest` WHERE (`id` = '500007');
INSERT INTO `quest` (`id`, `name`, `min_Delta`, `max_Solves`, `message`, `last_Modified`) VALUES ('500007', 'IH', '518400', '10', 'Tatoo', '2019-09-05 19:03:38');