the files in Restart PC shut down ace, restart the PC the restart ACE, I have the database set to automatically update so it will download and update any new items created by ACE. This can potentually cause issues if you do not also update the server software.

The files in Set ACE xp set double xp and lum on fridays and then set it back to normal on Mondays.

if you import the tsk schedules into task scheduler, you may need to edit the tasks to point to the auotmation scripts depending on where they are on your server. I had them save in C:\ACE\Automation Scripts if you place then there you shouldnt have any trouble.